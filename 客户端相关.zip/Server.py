# import socket programming library
import socket

# import thread module
from _thread import *
import threading

from sklearn.externals import joblib
import pandas as pd
import numpy as np
dirs = 'result'
hypermodel = joblib.load(dirs+'/hypermodel.pkl')
animal_ID_MAGO_7H_data = joblib.load(dirs+'/results_data.txt')
queue_input_ = joblib.load(dirs+'/results_queue_.txt')
memory_days=joblib.load(dirs+'/memory_days.txt')
pre_days=joblib.load(dirs+'/pre_days.txt')

dialogue={'Can you predict and give me the location of Marbled Godwits near Ugashik, Alaska, in June of 2012?':\
              'Yes, please give me an actual date after 2012/05/27 and before 2012/07/01.'}
def date_predict(start_time,predict_datetime,queue_input):
    std_=np.std(animal_ID_MAGO_7H_data.iloc[:,:-2])
    mean_=np.mean(animal_ID_MAGO_7H_data.iloc[:,:-2])
    num_loop=len(list(pd.date_range(start=start_time, end=predict_datetime, freq='D')))-pre_days+1
    std1=std_
    mean1=mean_
    queue_input_=queue_input
    for b in range(1,memory_days):
        std1=np.row_stack((std1,std_))
        mean1=np.row_stack((mean1,mean_))
    for a in range(1,num_loop):
        output_new=hypermodel.predict(queue_input_[-2*pre_days+1:-pre_days+1])
        queue_input_=np.row_stack([queue_input_,[(output_new-mean1)/std1]])
    return output_new


print_lock=threading.Lock()


# thread function
def threaded(c):
    while True:

        # data received from client
        data_raw=c.recv(1024)
        data=str(data_raw.decode('ascii'))

        if not data:
            print('Bye')

            # lock released on exit
            print_lock.release()
            break

        # # reverse the given string from client
        # if pred_location.get(data)==None:
        #     data="Can't predict this time point."
        else:
            if data.find('2012/06')!=-1 or data.find('2012/05/28')!=-1 or data.find('2012/05/29')!=-1 or \
                            data.find('2012/05/30')!=-1 or data.find('2012/05/31')!=-1:
                datetime=data
                predict_date=date_predict(animal_ID_MAGO_7H_data.index[-pre_days],datetime,queue_input_)
                long = round(100*predict_date[-1][0])/100
                lat= round(100*predict_date[-1][1])/100
                data='%f%s%f' % (long, '_', lat)
                print(long)
                print(data)
                # send back reversed string to client
            elif data in dialogue.keys():
                data=dialogue[data]
            else:
                data='You have given me a wrong date or in a wrong format, please check and resend.'
        c.send(data.encode('ascii'))

    # connection closed
    c.close()

def Main():
    host=""

    # reverse a port on your computer
    # in out case it is 12345 but it
    # can be anything
    port=12345
    s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    s.bind((host,port))
    print("socket binded to post", port)

    # put the socket into listening mode
    s.listen(5)
    print("socket is listening")

    # a forever loop until client wants to exit
    while True:

        # establish connection with client
        c, addr=s.accept()

        # lock acquired by client
        print_lock.acquire()
        print('Connected to :',addr[0], ':',addr[1])

        # Start a new thread and return its identifier
        start_new_thread(threaded,(c,))
    s.close()

if __name__=='__main__':
    Main()